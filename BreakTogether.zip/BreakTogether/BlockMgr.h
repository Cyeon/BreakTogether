#pragma once
class BlockMgr
{
private:
	
	BlockMgr();
	~BlockMgr();
public:
	SINGLE(BlockMgr);
};