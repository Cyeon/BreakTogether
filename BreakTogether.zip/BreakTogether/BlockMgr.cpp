#include "pch.h"
#include "BlockMgr.h"
#include "Block.h"
BlockMgr::BlockMgr()
{
}

BlockMgr::~BlockMgr()
{
}
