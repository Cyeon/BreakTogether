#pragma once
#include "Res.h"

class Sound :
	public Res
{
};
