#include "pch.h"
#include "Res.h"

Res::Res()
{
}

Res::~Res()
{
}
