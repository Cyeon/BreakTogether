#pragma once

// �̸� �����ϵ� ���
#include <windows.h>
#include "define.h"
#include "Vec2.h"
#include "framework.h"
#include <vector>
#include <map>
#include <iostream>
#include <string>
#define _USE_MATH_DEFINES // for C++
#include <math.h>
using namespace std;
#include "func.h"
#pragma comment(lib, "Msimg32.lib")
